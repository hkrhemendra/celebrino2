from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_mail import Mail
from itsdangerous import URLSafeTimedSerializer

#Flask app
app = Flask(__name__)
app.secret_key = 'The secret to backdoor'
app.config['SECRET_KEY'] = 'Trolific.com/celebrino'
#To Upload files
UPLOAD_FOLDER = 'D:\\Celebroz\\fooyes_v.1.3\\Flask\\celebrino\\static\\venue\\'
ALLOWED_EXTENSIONS = {'jpg', 'jpeg'}
ALLOWED_EXTENSIONS_GALLERY = {'jpg','jpeg','mp4'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

#Tokenization
s = URLSafeTimedSerializer("Thisismyscrete")

#Database config
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost/celebrino'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
db = SQLAlchemy(app)

# Bcrypt
bcrypt = Bcrypt(app)

#Mail service
app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'sheowest@gmail.com'
app.config['MAIL_PASSWORD'] = 'Sheowes@trolific'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True

mail = Mail(app)
